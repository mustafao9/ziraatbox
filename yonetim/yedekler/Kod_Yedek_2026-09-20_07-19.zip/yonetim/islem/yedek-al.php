<?php
/**
 * ZiraatBox - Esnek & Dinamik Yedekleme Motoru (Localhost / Server Uyumlu)
 */
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

require_once "../../sistem/ayar.php";

// 🔐 GÜVENLİK VE YETKİ
if (!isset($_SESSION['admin_id']) OR ($_SESSION['yetki'] ?? '') != 'admin') {
    die("Yetkisiz erişim!");
}

set_time_limit(600);
ini_set('memory_limit', '512M');

$tip = $_GET['tip'] ?? ($_POST['tip'] ?? 'sql');
$tarih = date("Y-m-d_H-i");

// 📂 DİNAMİK DİZİN TESPİTİ (Localhost ve Gerçek Server Uyumlu)
// ayar.php /public_html/sistem/ayar.php konumundadır. Bir üstü tam kök dizindir (public_html).
$rootPath = realpath(__DIR__ . '/../../'); 
$yedek_klasor = $rootPath . '/yonetim/yedekler/';

if (!is_dir($yedek_klasor)) { 
    @mkdir($yedek_klasor, 0775, true); 
}

// --- SQL DÖKÜM FONKSİYONU ---
function veritabaniYedekle($db) {
    $return = "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\n\n";
    $tables = array();
    $result = $db->query('SHOW TABLES');
    while($row = $result->fetch(PDO::FETCH_NUM)) { $tables[] = $row[0]; }
    
    foreach($tables as $table) {
        $row2 = $db->query('SHOW CREATE TABLE '.$table)->fetch(PDO::FETCH_NUM);
        $return .= "\n\n".$row2[1].";\n\n";
        $result = $db->query('SELECT * FROM '.$table);
        $num_fields = $result->columnCount();
        
        while($row = $result->fetch(PDO::FETCH_NUM)) {
            $return .= 'INSERT INTO '.$table.' VALUES(';
            for($j=0; $j<$num_fields; $j++) {
                if (isset($row[$j])) {
                    $val = addslashes($row[$j]);
                    $val = str_replace("\n","\\n",$val);
                    $return .= '"'.$val.'"';
                } else { $return .= 'NULL'; }
                if ($j<($num_fields-1)) { $return .= ','; }
            }
            $return .= ");\n";
        }
    }
    $return .= "\nSET FOREIGN_KEY_CHECKS=1;";
    return $return;
}

// --- İŞLEM BAŞLASIN ---
try {
    // 💾 A) SADECE SQL YEDEĞİ
    if ($tip == 'sql') {
        $sql_icerik = veritabaniYedekle($db);
        $dosya_adi = "DB_Yedek_".$tarih.".sql";
        
        file_put_contents($yedek_klasor . $dosya_adi, $sql_icerik);
        header("Location: ../yedekleme.php?islem=ok");
        exit;
    }

    // 📦 B) KOD + SQL VEYA FULL YEDEK
    if ($tip == 'full' OR $tip == 'no_images') {
        $zip = new ZipArchive();
        $dosya_adi = ($tip == 'full' ? 'FULL_Yedek_' : 'Kod_Yedek_') . $tarih . ".zip";
        $tam_yol = $yedek_klasor . $dosya_adi;

        if ($zip->open($tam_yol, ZipArchive::CREATE OR ZipArchive::OVERWRITE) === TRUE) {

            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($rootPath, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );

            foreach ($files as $name => $file) {
                if (!$file->isDir()) {
                    $filePath = $file->getRealPath();
                    $relativePath = substr($filePath, strlen($rootPath) + 1);
                    $normalizedPath = str_replace('\\', '/', $relativePath);

                    // 1. .env ve gizli sistem engeli
                    if (basename($normalizedPath) === '.env' OR strpos($normalizedPath, '.env') !== false) continue;
                    if (strpos($normalizedPath, '.git') !== false) continue;
                    if (strpos($normalizedPath, '.vscode') !== false) continue;

                    // 2. YEDEKLERİ YEDEKTEN HARİÇ TUT (Sonsuz Döngü Engellendi)
                    if (strpos($normalizedPath, 'yonetim/yedekler/') !== false OR strpos($normalizedPath, 'yedekler/') !== false) continue;
                    
                    $ext = strtolower(pathinfo($normalizedPath, PATHINFO_EXTENSION));
                    if ($ext === 'zip' OR $ext === 'sql') continue;

                    // 3. YÜKLENEN RESİMLERİ HARİÇ TUT (no_images modunda)
                    if ($tip == 'no_images') {
                        if (strpos($normalizedPath, 'uploads/') !== false OR strpos($normalizedPath, 'yuklemeler/') !== false) continue;
                    }

                    $zip->addFile($filePath, $relativePath);
                }
            }

            // SQL dökümünü zip içine koy
            $zip->addFromString("veritabani_yedek.sql", veritabaniYedekle($db));
            $zip->close();

            header("Location: ../yedekleme.php?islem=ok");
            exit;
        } else {
            die("Hata: ZIP dosyası oluşturulamadı!");
        }
    }
} catch (Exception $e) {
    die("Yedekleme Hatası: " . $e->getMessage());
}
