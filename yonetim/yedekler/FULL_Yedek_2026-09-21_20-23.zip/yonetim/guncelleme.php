<?php 
require_once "../sistem/ayar.php"; 

if(!isset($_SESSION['admin_id']) || $_SESSION['yetki'] != 'admin'){
    header("Location: giris.php"); exit;
}

$mevcut_versiyon = defined('SISTEM_VERSIYON') ? SISTEM_VERSIYON : '1.0.0';

// 📡 GITHUB API ILE SON VERSIYON KONTROLÜ
$github_repo = "mustafao9/ziraatbox";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.github.com/repos/$github_repo/releases/latest");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERAGENT, 'ZiraatBox-AutoUpdater');
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
$response = curl_exec($ch);
curl_close($ch);

$guncelleme_var = false;
$son_versiyon = $mevcut_versiyon;
$release_notlari = "";
$zip_url = "";

if ($response) {
    $data = json_decode($response, true);
    if (isset($data['tag_name'])) {
        $son_versiyon = ltrim($data['tag_name'], 'v');
        $release_notlari = $data['body'] ?? 'Sürüm notu girilmemiş.';
        $zip_url = $data['zipball_url'] ?? '';

        if (version_compare($son_versiyon, $mevcut_versiyon, '>')) {
            $guncelleme_var = true;
        }
    }
}

// OTOMATİK ROLLBACK YEDEKLERİNİ BUL
$yedek_dizini = __DIR__ . "/yedekler/";
$rollback_yedekleri = [];
if (is_dir($yedek_dizini)) {
    $files = array_diff(scandir($yedek_dizini), ['.', '..']);
    foreach ($files as $f) {
        if (strpos($f, 'AUTO_BEFORE_UPDATE_') !== false && pathinfo($f, PATHINFO_EXTENSION) === 'zip') {
            $rollback_yedekleri[] = $f;
        }
    }
    rsort($rollback_yedekleri); // En yeni üstte
}

// MESAJ DÜZENLEME
$mesaj = ""; $mesaj_tur = "";
if (isset($_GET['durum'])) {
    switch ($_GET['durum']) {
        case 'guncellendi': $mesaj = "🚀 Tebrikler! Sistem başarıyla v" . htmlspecialchars($_GET['v'] ?? '') . " sürümüne güncellendi ve veritabanı senkronize edildi."; $mesaj_tur = "success"; break;
        case 'rollback_ok': $mesaj = "🔄 Sistem başarıyla güncelleme öncesi stabil haline geri döndürüldü!"; $mesaj_tur = "warning"; break;
        case 'hata': $mesaj = "❌ Hata: " . htmlspecialchars($_GET['msg'] ?? 'İşlem başarısız.'); $mesaj_tur = "danger"; break;
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sistem Güncelleme Merkezi | ZiraatBox</title>
    <style>
        :root { --admin-dark: #1a202c; --admin-green: #27ae60; --admin-orange: #ed8936; --admin-blue: #3182ce; --admin-red: #e53e3e; }
        body { margin: 0; font-family: 'Segoe UI', sans-serif; background: #f4f7f6; display: flex; }
        .sidebar { width: 260px; background: var(--admin-dark); color: #fff; min-height: 100vh; padding: 20px; box-sizing: border-box; position: sticky; top: 0; }
        .content { flex: 1; padding: 30px; box-sizing: border-box; }
        .view-site-btn { display: flex; align-items: center; justify-content: center; background: var(--admin-green); color: #fff; text-decoration: none; padding: 12px; border-radius: 8px; margin-bottom: 25px; font-weight: 600; font-size: 14px; }
        .sidebar a { display: block; color: #cbd5e0; padding: 12px; text-decoration: none; border-radius: 8px; margin-bottom: 5px; transition: 0.3s; font-size: 14px; }
        .sidebar a:hover, .sidebar a.active { background: #2d3748; color: #fff; }

        .card { background: #fff; padding: 25px; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 25px; }
        .version-badge { display: inline-block; padding: 6px 12px; border-radius: 20px; font-weight: 800; font-size: 13px; }
        .badge-current { background: #e2e8f0; color: #2d3748; }
        .badge-latest { background: #dcfce7; color: #166534; }
        .badge-new { background: #feebc8; color: #c05621; }

        .btn { padding: 14px 28px; border-radius: 10px; font-weight: 800; text-decoration: none; display: inline-block; cursor: pointer; border: none; font-size: 14px; transition: 0.2s; }
        .btn-update { background: var(--admin-green); color: white; }
        .btn-update:hover { background: #219653; }
        .btn-rollback { background: var(--admin-orange); color: white; }
        .btn-rollback:hover { background: #dd6b20; }

        .alert { padding: 16px 20px; border-radius: 10px; margin-bottom: 25px; font-weight: 700; font-size: 14px; }
        .alert-success { background: #dcfce7; color: #166534; border-left: 5px solid #22c55e; }
        .alert-warning { background: #fef3c7; color: #92400e; border-left: 5px solid #f59e0b; }
        .alert-danger { background: #fee2e2; color: #991b1b; border-left: 5px solid #ef4444; }

        .notes-box { background: #f8fafc; border: 1px solid #e2e8f0; padding: 15px; border-radius: 10px; font-family: monospace; font-size: 13px; color: #475569; white-space: pre-wrap; margin: 15px 0; }
    </style>
</head>
<body>

<div class="sidebar">
    <h2 style="color: #48bb78; margin-bottom: 30px;">Ziraat<span style="color: #f39c12;">Box</span></h2>
    <a href="../index.php" target="_blank" class="view-site-btn">🌐 Siteyi Görüntüle</a>
    <nav>
        <a href="index.php">🏠 Panel Özeti</a>
        <a href="ziyaretciler.php">📈 Ziyaretçi Analizi</a> 
        <a href="ilanlar.php">📦 İlan Yönetimi</a>
        <a href="sikayetler.php">🛡️ Şikayetler</a>
        <a href="kategoriler.php">📂 Kategori Yönetimi</a>
        <a href="uyeler.php">👥 Üye Yönetimi</a>
        <a href="mesajlar.php">💬 Mesajlar</a>
        
        <hr style="border: 0; border-top: 1px solid #2d3748; margin: 15px 0;">
        <a href="yedekleme.php">🗄️ Sistem Yedekleme</a>
        <a href="guncelleme.php" class="active">🚀 Sistem Güncelleme</a>
        <a href="ayarlar.php">⚙️ Genel Ayarlar</a>
        <a href="cikis.php" style="color: #fc8181;">🚪 Güvenli Çıkış</a>
    </nav>
</div>

<div class="content">
    <h1 style="margin: 0 0 30px; color: #1a202c; font-size: 26px;">🚀 Canlı Sunucu Otomatik Güncelleme Merkezi</h1>

    <?php if ($mesaj): ?>
        <div class="alert alert-<?php echo $mesaj_tur; ?>"><?php echo $mesaj; ?></div>
    <?php endif; ?>

    <!-- STATUS CARD -->
    <div class="card">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h2 style="margin:0 0 10px; color:#2d3748;">Mevcut Sürüm: <span class="version-badge badge-current">v<?php echo $mevcut_versiyon; ?></span></h2>
                <p style="margin:0; color:#718096; font-size:14px;">GitHub Deposu: <b><?php echo $github_repo; ?></b></p>
            </div>
            <div>
                <?php if ($guncelleme_var): ?>
                    <span class="version-badge badge-new">Yeni Sürüm Mevcut: v<?php echo $son_versiyon; ?></span>
                <?php else: ?>
                    <span class="version-badge badge-latest">✅ Sisteminiz Güncel (v<?php echo $son_versiyon; ?>)</span>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($guncelleme_var): ?>
            <hr style="border:0; border-top:1px solid #edf2f7; margin:20px 0;">
            <h3 style="margin:0; color:#2d3748; font-size:16px;">📝 v<?php echo $son_versiyon; ?> Sürüm Notları:</h3>
            <div class="notes-box"><?php echo htmlspecialchars($release_notlari); ?></div>

            <div style="margin-top:20px;">
                <a href="islem/guncelle-yap.php?islem=guncelle&version=<?php echo $son_versiyon; ?>" 
                   onclick="return confirm('Sistem güncellenecektir. İşlemden önce otomatik tam yedek alınacaktır. Onaylıyor musunuz?')" 
                   class="btn btn-update">⚡ ŞİMDİ OTOMATİK GÜNCELLE (v<?php echo $son_versiyon; ?>)</a>
            </div>
        <?php else: ?>
            <div style="margin-top:20px;">
                <a href="guncelleme.php" class="btn" style="background:#edf2f7; color:#4a5568;">🔄 Yeniden Kontrol Et</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- ROLLBACK CARD -->
    <div class="card" style="border-top: 4px solid var(--admin-orange);">
        <h2 style="margin:0 0 10px; color:#2d3748;">🔄 Güncelleme İptali / Eskiye Dönüş (Rollback)</h2>
        <p style="color:#718096; font-size:14px; margin-bottom:20px;">
            Son güncellenen sürümde bir sorun yaşarsanız, güncellemeden hemen önce otomatik alınan yedeği tek tıkla geri yükleyerek sisteminizi eski stabil haline döndürebilirsiniz.
        </p>

        <?php if (!empty($rollback_yedekleri)): ?>
            <table style="width:100%; border-collapse:collapse;">
                <thead>
                    <tr style="background:#f8fafc; text-align:left;">
                        <th style="padding:10px; border-bottom:1px solid #e2e8f0; font-size:12px; color:#64748b;">GÜNCELLEME ÖNCESİ YEDEK DOSYASI</th>
                        <th style="padding:10px; border-bottom:1px solid #e2e8f0; font-size:12px; color:#64748b; text-align:right;">İŞLEM</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rollback_yedekleri as $r_dosya): ?>
                        <tr>
                            <td style="padding:12px; border-bottom:1px solid #f1f5f9;">
                                <b><?php echo $r_dosya; ?></b><br>
                                <small style="color:#94a3b8;"><?php echo date("d.m.Y H:i", filemtime($yedek_dizini . $r_dosya)); ?></small>
                            </td>
                            <td style="text-align:right; padding:12px; border-bottom:1px solid #f1f5f9;">
                                <a href="islem/guncelle-yap.php?islem=rollback&dosya=<?php echo urlencode($r_dosya); ?>" 
                                   onclick="return confirm('⚠️ DİKKAT: Sistem güncelleme öncesi haline geri yüklenecektir! Onaylıyor musunuz?')" 
                                   class="btn btn-rollback" style="padding:8px 16px; font-size:12px;">⚠️ Son Güncellemeyi Geri Al</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div style="color:#a0aec0; font-size:13px; font-style:italic;">Henüz kaydedilmiş güncelleme öncesi rollback yedeği bulunmuyor.</div>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
