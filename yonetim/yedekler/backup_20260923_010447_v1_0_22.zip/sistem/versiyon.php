<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
/**
 * ZiraatBox - Otomatik Sürüm Dosyası
 */
define('SISTEM_VERSIYON', '1.0.22');
