<?php

$surum = '1.0.18';

$versiyon = $surum;
