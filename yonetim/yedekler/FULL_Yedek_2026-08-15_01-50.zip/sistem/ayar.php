<?php
/**
 * ZiraatBox - Akıllı Yapılandırma Dosyası (CANLI SUNUCU FİNAL + TRAFİK TAKİP)
 * Mustafa Satılmış - İncirliova / Aydın
 */

session_start();
ob_start();

// 1. Veritabanı Bilgileri
$host       = "localhost";
$veritabani = "ziraatbo_ziraatbox";
$kullanici  = "ziraatbo_ziraatbox";
$sifre      = "Aa63856385*"; 

try {
    $db = new PDO("mysql:host=$host;dbname=$veritabani;charset=utf8mb4", $kullanici, $sifre, [
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4",
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_PERSISTENT => true 
    ]);
} catch (PDOException $e) {
    die("Sistem şu an teknik bir çalışma nedeniyle bakım aşamasındadır.");
}

// 2. DİNAMİK URL TANIMLAMA
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https://" : "http://";
$domain   = $_SERVER['HTTP_HOST'];
define('URL', $protocol . $domain); 
define('SITE_ADI', 'ZiraatBox');

// 3. Google reCAPTCHA Anahtarları
define('RECAPTCHA_SITE_KEY', '6Lf5NYQsAAAAALvt4iKM_jQrkHLVW5KweD0IH7Kv');
define('RECAPTCHA_SECRET_KEY', '6Lf5NYQsAAAAAJaz-uufBTKAssBgwm4WQa7W7aF2');

/**
 * 🚀 IP YAKALAMA FONKSİYONU (IPv4 Öncelikli)
 */
function get_client_ip() {
    $ip = 'UNKNOWN';
    if (isset($_SERVER['HTTP_CLIENT_IP'])) $ip = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR'])) $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['REMOTE_ADDR'])) $ip = $_SERVER['REMOTE_ADDR'];
    
    // Eğer IPv6 localhost ise (::1), 127.0.0.1'e çevirir
    if($ip == '::1') $ip = '127.0.0.1';
    return $ip;
}

// 4. Yardımcıları Çağır
if (file_exists(__DIR__ . "/fonksiyonlar.php")) {
    require_once __DIR__ . "/fonksiyonlar.php";
}

// 5. ZİYARETÇİ TAKİP MOTORU
try {
    $ip = get_client_ip();
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown';
    $is_bot = (preg_match('/bot|crawl|slurp|spider|mediapartners|google|yandex|bing/i', $ua)) ? 1 : 0;

    $kontrol = $db->prepare("SELECT id FROM ziyaretler WHERE ip_adresi = ? AND tarih > DATE_SUB(NOW(), INTERVAL 1 HOUR) LIMIT 1");
    $kontrol->execute([$ip]);
    
    if($kontrol->rowCount() == 0){
        $ekle = $db->prepare("INSERT INTO ziyaretler (ip_adresi, user_agent, is_bot, tarih) VALUES (?, ?, ?, NOW())");
        $ekle->execute([$ip, $ua, $is_bold]);
    }
} catch (Exception $e) {}

// 6. Otomatik İlan Süresi Kontrolü
try {
    $db->query("UPDATE ilanlar SET durum = 'pasif' WHERE bitis_tarihi < NOW() AND durum = 'aktif'");
} catch (Exception $e) {}
?>