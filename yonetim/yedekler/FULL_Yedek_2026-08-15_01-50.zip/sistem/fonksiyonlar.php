<?php
/**
 * ZiraatBox - Genel Yardımcı Fonksiyonlar
 * Mustafa Satılmış - Webmaster
 */

// 🛡️ 1. GÜVENLİK: VERİ TEMİZLEME FONKSİYONU (Kayıp olan fonksiyon)
if (!function_exists('g')) {
    function g($data) {
        if (is_array($data)) {
            return array_map('g', $data);
        }
        // HTML etiketlerini temizler, boşlukları alır ve zararlı karakterleri etkisizleştirir
        return htmlspecialchars(trim(strip_tags($data)));
    }
}

// 🔗 2. SEO: SEF LINK OLUŞTURUCU (Kategori slug'ları için şart)
if (!function_exists('sef_link')) {
    function sef_link($str) {
        $preg = array('Ç', 'Ş', 'Ğ', 'Ü', 'İ', 'Ö', 'ç', 'ş', 'ğ', 'ü', 'ö', 'ı', '+', '#', '.', ',', '(', ')', '[', ']', '{', '}', '?', '&', '=', '!', '"', "'");
        $replace = array('c', 's', 'g', 'u', 'i', 'o', 'c', 's', 'g', 'u', 'o', 'i', 'plus', 'sharp', '', '', '', '', '', '', '', '', '', '', '', '', '', '');
        $str = str_replace($preg, $replace, $str);
        $str = preg_replace("@[^A-Za-z0-9\-_]@i", ' ', $str);
        $str = trim(preg_replace('/\s\s+/', ' ', $str));
        $str = str_replace(' ', '-', $str);
        return strtolower($str);
    }
}

// 🌳 3. KATEGORİ: SONSUZ HİYERARŞİ FONKSİYONU
function kategoriListeleAltli($db, $ust_id = 0, $derinlik = 0, $secili = 0) {
    $sorgu = $db->prepare("SELECT id, adi FROM kategoriler WHERE ust_id = ? AND aktif = 1 ORDER BY sira ASC");
    $sorgu->execute([$ust_id]);
    foreach($sorgu->fetchAll() as $kat) {
        $sel = ($kat['id'] == $secili) ? 'selected' : '';
        $girinti = str_repeat('&nbsp;&nbsp;&nbsp;', $derinlik);
        $simge = ($derinlik == 0) ? "📂 " : "└─ ";
        $stil = ($derinlik == 0) ? "font-weight:900; background:#f0fdf4; color:#1b4332;" : "font-weight:400;";
        
        echo '<option value="'.$kat['id'].'" '.$sel.' style="'.$stil.'">'.$girinti.$simge.$kat['adi'].'</option>';
        // Kendini tekrar çağırarak alt kategorilere iner
        kategoriListeleAltli($db, $kat['id'], $derinlik + 1, $secili);
    }
}

// 🗺️ 4. NAVİGASYON: SOYAĞACI (BREADCRUMB) OLUŞTURUCU
function katYoluGetir($db, $kat_id) {
    $yol = [];
    $temp_id = $kat_id;
    while ($temp_id > 0) {
        $s = $db->prepare("SELECT id, adi, slug, ust_id FROM kategoriler WHERE id = ?");
        $s->execute([$temp_id]);
        $k = $s->fetch();
        if ($k) {
            array_unshift($yol, '<a href="kategori.php?slug='.$k['slug'].'" style="color:#27ae60; text-decoration:none; font-weight:700;">'.$k['adi'].'</a>');
            $temp_id = $k['ust_id'];
        } else { break; }
    }
    return implode(' <span style="color:#cbd5e0;">&gt;</span> ', $yol);
}
?>