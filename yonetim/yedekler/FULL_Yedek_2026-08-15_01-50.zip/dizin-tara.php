<?php
/**
 * ZiraatBox - Dosya Yapısı Tarayıcı
 * Sadece geliştirme aşamasında kullanın!
 */

header('Content-Type: text/html; charset=utf-8');

function dizinListele($dizin, $bosluk = "") {
    // Taranmasını istemediğimiz klasörler (vendor çok kalabalık olduğu için sadece varlığını kontrol edelim)
    $yasakli = array(".", "..", ".git", ".vscode", "node_modules");
    
    $dosyalar = scandir($dizin);

    foreach ($dosyalar as $dosya) {
        if (in_array($dosya, $yasakli)) continue;

        if (is_dir($dizin . "/" . $dosya)) {
            echo "<strong>" . $bosluk . "📁 " . $dosya . "</strong><br>";
            // Vendor klasörünün içindeki binlerce dosyayı listelemeyelim, sadece klasörü gösterelim
            if ($dosya !== 'vendor') {
                dizinListele($dizin . "/" . $dosya, $bosluk . "&nbsp;&nbsp;&nbsp;&nbsp;");
            } else {
                echo $bosluk . "&nbsp;&nbsp;&nbsp;&nbsp; (Kütüphaneler İçeride)<br>";
            }
        } else {
            echo $bosluk . "📄 " . $dosya . "<br>";
        }
    }
}

echo "<h2>🚜 ZiraatBox Sunucu Dosya Yapısı</h2>";
echo "<div style='font-family: monospace; background: #f4f4f4; padding: 20px; border-radius: 10px; line-height: 1.6;'>";
dizinListele(__DIR__);
echo "</div>";
?>