<?php
ob_start();
require_once __DIR__ . "/../sistem/ayar.php";
require_once __DIR__ . "/google-ayarlar.php"; 

$active_client = isset($google_client) ? $google_client : $client;

if (isset($_GET['code'])) {
    try {
        $active_client->authenticate($_GET['code']);
        $token = $active_client->getAccessToken();
        $active_client->setAccessToken($token);
        
        $google_oauth = new Google_Service_Oauth2($active_client);
        $google_account_info = $google_oauth->userinfo->get();
        
        $email       = $google_account_info->email;
        $ad_soyad    = $google_account_info->name;
        $google_uid  = $google_account_info->id;
        $remote_img  = $google_account_info->picture;

        $sorgu = $db->prepare("SELECT * FROM uyeler WHERE email = ? LIMIT 1");
        $sorgu->execute([$email]);
        $uye = $sorgu->fetch();

        if ($uye) {
            // Mevcut kullanıcıysa sadece google_id yoksa ekle
            if(empty($uye['google_id'])){
                $db->prepare("UPDATE uyeler SET google_id = ? WHERE id = ?")->execute([$google_uid, $uye['id']]);
            }
            $_SESSION['uye_id'] = $uye['id'];
        } else {
            // YENİ KAYIT: Google Resmini Sunucuya İndir
            $yeni_resim_adi = "google_" . time() . ".jpg";
            $resim_icerik = @file_get_contents($remote_img);
            if($resim_icerik) {
                file_put_contents("../yuklemeler/profil/" . $yeni_resim_adi, $resim_icerik);
            } else {
                $yeni_resim_adi = NULL;
            }

            $kullanici_adi = strstr($email, '@', true) . rand(100, 999);
            
            // Şifreyi boş (NULL) bırakıyoruz, google_id ekliyoruz
            $kaydet = $db->prepare("INSERT INTO uyeler SET kullanici_adi = ?, email = ?, ad_soyad = ?, profil_foto = ?, google_id = ?, durum = 'aktif', yetki = 'uye', sifre = NULL");
            $kaydet->execute([$kullanici_adi, $email, $ad_soyad, $yeni_resim_adi, $google_uid]);

            $_SESSION['uye_id'] = $db->lastInsertId();
        }

        header("Location: " . URL . "/index.php");
        exit;
    } catch (Exception $e) { die($e->getMessage()); }
}