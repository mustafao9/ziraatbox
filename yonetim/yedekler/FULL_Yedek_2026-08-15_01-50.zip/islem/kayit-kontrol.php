<?php
/**
 * ZiraatBox - Kayıt Kontrol Motoru v2.6
 * 500 Hatası Giderilmiş, Garantili Sürüm
 */

require_once "../sistem/ayar.php";

if ($_POST) {
    // 1. RECAPTCHA KONTROLÜ
    if (isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])) {
        $secret = RECAPTCHA_SECRET_KEY;
        $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
        $responseData = json_decode($verifyResponse);
        if (!$responseData->success) {
            $_SESSION['mesaj'] = "Lütfen robot olmadığınızı doğrulayın.";
            header("Location: ../kayit.php");
            exit;
        }
    }

    // 2. VERİLERİ AL VE TEMİZLE (Hata riskini sıfırlamak için g() yerine doğrudan filtreleme)
    $ad_soyad     = strip_tags(trim($_POST['ad_soyad']));
    $eposta       = filter_var(trim($_POST['eposta']), FILTER_SANITIZE_EMAIL);
    $telefon      = strip_tags(trim($_POST['telefon']));
    $sifre        = $_POST['sifre'];
    $sifre_tekrar = $_POST['sifre_tekrar'];

    // 3. BOŞ ALAN VE ŞİFRE KONTROLÜ
    if (empty($ad_soyad) || empty($eposta) || empty($sifre)) {
        $_SESSION['mesaj'] = "Lütfen tüm zorunlu alanları doldurun.";
        header("Location: ../kayit.php");
        exit;
    }

    if ($sifre !== $sifre_tekrar) {
        $_SESSION['mesaj'] = "Girdiğiniz şifreler birbiriyle eşleşmiyor.";
        header("Location: ../kayit.php");
        exit;
    }

    if (strlen($sifre) < 6) {
        $_SESSION['mesaj'] = "Şifreniz en az 6 karakter olmalıdır.";
        header("Location: ../kayit.php");
        exit;
    }

    try {
        // 4. E-POSTA MÜKERRER KONTROLÜ
        $kontrol = $db->prepare("SELECT id FROM uyeler WHERE eposta = ?");
        $kontrol->execute([$eposta]);
        if ($kontrol->rowCount() > 0) {
            $_SESSION['mesaj'] = "Bu e-posta adresi zaten sisteme kayıtlı.";
            header("Location: ../kayit.php");
            exit;
        }

        // 5. KAYIT İŞLEMİ
        $sifre_hash = password_hash($sifre, PASSWORD_DEFAULT);
        $kullanici_adi = strstr($eposta, '@', true) . rand(100, 999); 

        $ekle = $db->prepare("INSERT INTO uyeler SET 
            kullanici_adi = ?, 
            eposta = ?, 
            ad_soyad = ?, 
            telefon = ?, 
            sifre = ?, 
            yetki = 'uye', 
            durum = 'aktif'");
        
        $sonuc = $ekle->execute([
            $kullanici_adi, 
            $eposta, 
            $ad_soyad, 
            $telefon, 
            $sifre_hash
        ]);

        if ($sonuc) {
            // Oturum Açma
            $yeni_id = $db->lastInsertId();
            $_SESSION['uye_id']   = $yeni_id;
            $_SESSION['ad_soyad'] = $ad_soyad;
            $_SESSION['yetki']    = 'uye';

            $_SESSION['mesaj'] = "ZiraatBox ailesine hoş geldiniz! Kaydınız başarıyla tamamlandı.";
            header("Location: ../hesabim.php");
        } else {
            $_SESSION['mesaj'] = "Teknik bir sorun oluştu, lütfen tekrar deneyin.";
            header("Location: ../kayit.php");
        }

    } catch (PDOException $e) {
        // Veritabanı sütun isimleri uyuşmazsa burası hatayı yakalar
        $_SESSION['mesaj'] = "Sistem Hatası: Sütun isimlerini kontrol edin.";
        header("Location: ../kayit.php");
    }
    exit;
} else {
    header("Location: ../index.php");
    exit;
}