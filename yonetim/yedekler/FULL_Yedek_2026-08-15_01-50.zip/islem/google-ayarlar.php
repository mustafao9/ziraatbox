<?php
/**
 * ZiraatBox - Google API Ayarları (YENİLENMİŞ ANAHTARLAR)
 */
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../sistem/ayar.php';

if (session_status() == PHP_SESSION_NONE) { session_start(); }

$google_client = new Google_Client();

// 🚀 YENİ OLUŞTURDUĞUNUZ ANAHTARLAR
$google_client->setClientId('791183433749-6uftehnnn7suetlru8gjcf0cnh2dckvl.apps.googleusercontent.com');
$google_client->setClientSecret('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');

// 🚀 YÖNLENDİRME ADRESİ
$google_client->setRedirectUri(URL . '/islem/google-callback.php');

$google_client->addScope('email');
$google_client->addScope('profile');

// Kütüphane uyumluluğu için ek ayarlar
$google_client->setAccessType('online');
$google_client->setApprovalPrompt('auto');
?>