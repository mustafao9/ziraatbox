<?php
require_once "../sistem/ayar.php";

// 1. GÜVENLİK: Oturum ve Yetki Kontrolü
if (!isset($_SESSION['uye_id'])) {
    header("Location: ../giris.php");
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$uye_id = $_SESSION['uye_id'];

if ($id > 0) {
    // 2. İLAN KONTROLÜ: İlan gerçekten bu üyeye mi ait? (Webmaster Güvenliği)
    $ilan_kontrol = $db->prepare("SELECT id FROM ilanlar WHERE id = ? AND uye_id = ?");
    $ilan_kontrol->execute([$id, $uye_id]);
    
    if ($ilan_kontrol->rowCount() > 0) {
        
        // 3. FİZİKSEL RESİMLERİ SİLME (Sunucu Temizliği)
        $resimler = $db->prepare("SELECT dosya_adi FROM ilan_resimleri WHERE ilan_id = ?");
        $resimler->execute([$id]);
        $resim_listesi = $resimler->fetchAll();

        $dizin = dirname(__DIR__) . DIRECTORY_SEPARATOR . "yuklemeler" . DIRECTORY_SEPARATOR . "ilanlar" . DIRECTORY_SEPARATOR;

        foreach ($resim_listesi as $r) {
            $tam_yol = $dizin . $r['dosya_adi'];
            if (file_exists($tam_yol)) {
                @unlink($tam_yol); // Dosyayı klasörden kalıcı olarak siler
            }
        }

        // 4. VERİTABANI TEMİZLİĞİ (İlişkili tüm verileri siler)
        // Önce resim kayıtlarını, sonra ilanı sileriz
        $db->prepare("DELETE FROM ilan_resimleri WHERE ilan_id = ?")->execute([$id]);
        $db->prepare("DELETE FROM favoriler WHERE ilan_id = ?")->execute([$id]);
        $db->prepare("DELETE FROM ilanlar WHERE id = ? AND uye_id = ?")->execute([$id, $uye_id]);

        $_SESSION['mesaj'] = "İlan ve bağlı tüm dosyalar kalıcı olarak silindi.";
        header("Location: ../hesabim.php?durum=silindi");
        exit;
    } else {
        // İlan bu üyeye ait değilse veya bulunamadıysa
        header("Location: ../hesabim.php?hata=yetkisiz");
        exit;
    }
} else {
    header("Location: ../index.php");
    exit;
}