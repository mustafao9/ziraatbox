<?php
require_once "../sistem/ayar.php";

/**
 * 🔗 MODERN SEO URL FONKSİYONU
 */
function seolink($val) {
    $yol = array('Ç', 'Ş', 'Ğ', 'Ü', 'İ', 'Ö', 'ç', 'ş', 'ğ', 'ü', 'ö', 'ı', '+', '#', '.');
    $yap = array('c', 's', 'g', 'u', 'i', 'o', 'c', 's', 'g', 'u', 'o', 'i', 'plus', 'sharp', '-');
    $val = str_replace($yol, $yap, $val);
    $val = mb_strtolower($val, 'UTF-8');
    $val = preg_replace('#[^-a-zA-Z0-9_ ]#', '', $val);
    $val = trim($val);
    $val = str_replace(' ', '-', $val);
    while (strpos($val, '--') !== false) { $val = str_replace('--', '-', $val); }
    return $val;
}

/**
 * ⚖️ GERÇEK IP YAKALAMA FONKSİYONU (5651 Uyumlu)
 */
function getRealIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

// 🔐 OTURUM KONTROLÜ
if (!isset($_SESSION['uye_id'])) { 
    die(json_encode(['durum' => 'hata', 'mesaj' => 'Yetkisiz erişim!'])); 
}

if ($_POST) {
    // 1. FORM VERİLERİNİ GÜVENLİCE ALALIM
    $uye_id      = $_SESSION['uye_id'];
    $baslik      = htmlspecialchars(trim($_POST['baslik']));
    $kategori_id = intval($_POST['kategori_id']);
    $satici_tipi = isset($_POST['satici_tipi']) ? htmlspecialchars($_POST['satici_tipi']) : 'Uretici';
    $fiyat       = str_replace(['.', ','], ['', '.'], $_POST['fiyat']); 
    $il_id       = intval($_POST['il_id']);
    $ilce_id     = intval($_POST['ilce_id']);
    $mahalle_id  = intval($_POST['mahalle_id']);
    $aciklama    = htmlspecialchars($_POST['aciklama']);
    
    // 🚀 GİZLİLİK VE İLETİŞİM AYARLARI
    $iletisim_tercihi = isset($_POST['iletisim_tercihi']) ? htmlspecialchars($_POST['iletisim_tercihi']) : 'hepsi';
    $isim_gizle       = isset($_POST['isim_gizle']) ? 1 : 0;
    
    // ⚖️ LOG BİLGİLERİ (Yer Sağlayıcı Sorumluluğu İçin)
    $ip_adresi  = getRealIP();
    $user_agent = $_SERVER['HTTP_USER_AGENT'];

    // SEO URL
    $slug = seolink($baslik) . "-" . time() . rand(10, 99);

    // 🎯 AKILLI İLAN NUMARASI
    $yil          = date('y');
    $yilun_gunu   = str_pad(date('z') + 1, 3, '0', STR_PAD_LEFT); 
    $saat_dakika  = date('Hi');             
    $saniye       = date('s');              
    $ozel_ilan_no = $yil . $yilun_gunu . $saat_dakika . $saniye;

    // 2. VERİTABANINA ANA KAYIT (IP ve User Agent Dahil)
    $ilan_ekle = $db->prepare("INSERT INTO ilanlar SET 
        ilan_no          = ?, 
        uye_id           = ?, 
        kategori_id      = ?, 
        satici_tipi      = ?, 
        baslik           = ?, 
        slug             = ?, 
        aciklama         = ?, 
        fiyat            = ?, 
        il               = ?, 
        ilce             = ?, 
        mahalle          = ?, 
        iletisim_tercihi = ?, 
        isim_gizle       = ?, 
        ip_adresi        = ?, 
        user_agent       = ?, 
        durum            = 'beklemede'");

    $kontrol = $ilan_ekle->execute([
        $ozel_ilan_no, $uye_id, $kategori_id, $satici_tipi, $baslik, $slug, $aciklama, $fiyat, 
        $il_id, $ilce_id, $mahalle_id, $iletisim_tercihi, $isim_gizle, $ip_adresi, $user_agent
    ]);

    if ($kontrol) {
        $last_id = $db->lastInsertId();

        // 🛠️ TEKNİK ÖZELLİKLERİ KAYDET
        if (isset($_POST['ozellik']) && is_array($_POST['ozellik'])) {
            $oz_kaydet = $db->prepare("INSERT INTO ilan_ozellik_verileri SET ilan_id = ?, ozellik_id = ?, deger = ?");
            foreach ($_POST['ozellik'] as $oz_id => $deger) {
                if (!empty($deger)) {
                    $oz_kaydet->execute([$last_id, intval($oz_id), htmlspecialchars($deger)]);
                }
            }
        }

        // 📸 RESİMLERİ YÜKLE
        if (isset($_FILES['ilan_resimleri']['name'][0]) && !empty($_FILES['ilan_resimleri']['name'][0])) {
            $hedef_yol = "../yuklemeler/ilanlar/";
            if (!file_exists($hedef_yol)) { mkdir($hedef_yol, 0777, true); }

            foreach ($_FILES['ilan_resimleri']['name'] as $i => $ad) {
                if ($_FILES['ilan_resimleri']['error'][$i] === UPLOAD_ERR_OK) {
                    $uzanti = strtolower(pathinfo($ad, PATHINFO_EXTENSION));
                    $gecerli_uzantilar = ['jpg', 'jpeg', 'png', 'webp'];

                    if (in_array($uzanti, $gecerli_uzantilar)) {
                        $yeni_ad = "zbox_" . uniqid() . "_" . $i . "." . $uzanti;
                        if (move_uploaded_file($_FILES['ilan_resimleri']['tmp_name'][$i], $hedef_yol . $yeni_ad)) {
                            $ana_resim = ($i == 0) ? 1 : 0;
                            $db->prepare("INSERT INTO ilan_resimleri SET ilan_id = ?, dosya_adi = ?, ana_resim = ?")
                               ->execute([$last_id, $yeni_ad, $ana_resim]);
                        }
                    }
                }
            }
        }

        header("Location: ../ilanlarim.php?islem=basarili&onay=bekliyor");
        exit;
    } else {
        die("Veritabanı hatası oluştu!");
    }
}
?>