<?php
/**
 * ZiraatBox - İlan Güncelleme Motoru (KESİN VE DOĞRU SÜRÜM)
 */
require_once "../sistem/ayar.php";

// 1. OTURUM VE YETKİ KONTROLÜ
if (!isset($_SESSION['uye_id'])) { 
    die("Yetkisiz erişim!"); 
}

if ($_POST) {
    // Formdan gelen ID ve Üye Bilgisi
    $id          = intval($_POST['id']);
    $uye_id      = $_SESSION['uye_id'];
    
    // Temel Bilgiler (ilan-duzenle.php'deki name özelliklerine göre)
    $baslik      = htmlspecialchars(trim($_POST['baslik']));
    $kategori_id = intval($_POST['kategori_id']);
    $fiyat       = str_replace(['.', ','], ['', '.'], $_POST['fiyat']); // 1.500,00 -> 1500.00
    $satici_tipi = htmlspecialchars($_POST['satici_tipi']); 
    $aciklama    = htmlspecialchars($_POST['aciklama']);
    
    // Konum Bilgileri (ilan-duzenle.php'deki name özelliklerine göre)
    $il_id       = intval($_POST['il_id']);
    $ilce_id     = intval($_POST['ilce_id']);
    $mahalle_id  = intval($_POST['mahalle_id']);
    
    // Güvenlik ve Log (Tablonuzda var olan sütunlara göre)
    $user_agent  = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Unknown';

    // 2. SAHİPLİK DOĞRULAMA
    $kontrol = $db->prepare("SELECT id FROM ilanlar WHERE id = ? AND uye_id = ?");
    $kontrol->execute([$id, $uye_id]);
    if (!$kontrol->fetch()) {
        die("Bu ilanı düzenleme yetkiniz bulunmuyor.");
    }

    // 3. ANA GÜNCELLEME SORGU (Sadece var olan sütunlar)
    // Sizin tablonuzda 'kayit_ip' olmadığı için onu çıkardım.
    $guncelle = $db->prepare("UPDATE ilanlar SET 
        baslik = ?, 
        fiyat = ?, 
        kategori_id = ?, 
        satici_tipi = ?, 
        aciklama = ?, 
        il = ?, 
        ilce = ?, 
        mahalle = ?, 
        durum = 'beklemede',
        user_agent = ?
        WHERE id = ? AND uye_id = ?");
    
    $sonuc = $guncelle->execute([
        $baslik, 
        $fiyat, 
        $kategori_id, 
        $satici_tipi, 
        $aciklama, 
        $il_id, 
        $ilce_id, 
        $mahalle_id, 
        $user_agent,
        $id, 
        $uye_id
    ]);

    if ($sonuc) {
        // 4. TEKNİK ÖZELLİKLER (ilan-duzenle.php içindeki dinamik alanlar)
        // Mevcutları temizleyip yenilerini giriyoruz
        $db->prepare("DELETE FROM ilan_ozellik_verileri WHERE ilan_id = ?")->execute([$id]);
        if (isset($_POST['ozellik']) && is_array($_POST['ozellik'])) {
            $oz_kaydet = $db->prepare("INSERT INTO ilan_ozellik_verileri (ilan_id, ozellik_id, deger) VALUES (?, ?, ?)");
            foreach ($_POST['ozellik'] as $oz_id => $deger) {
                if (trim($deger) !== "") {
                    $oz_kaydet->execute([$id, intval($oz_id), htmlspecialchars($deger)]);
                }
            }
        }

        // 5. RESİM SİLME (Checkbox: silinecek_resimler[])
        if (isset($_POST['silinecek_resimler']) && is_array($_POST['silinecek_resimler'])) {
            foreach ($_POST['silinecek_resimler'] as $resim_id) {
                $r_sorgu = $db->prepare("SELECT dosya_adi FROM ilan_resimleri WHERE id = ? AND ilan_id = ?");
                $r_sorgu->execute([intval($resim_id), $id]);
                $r_data = $r_sorgu->fetch();
                if ($r_data) {
                    $yol = "../../yuklemeler/ilanlar/" . $r_data['dosya_adi'];
                    if (file_exists($yol)) { @unlink($yol); }
                    $db->prepare("DELETE FROM ilan_resimleri WHERE id = ?")->execute([intval($resim_id)]);
                }
            }
        }

        // 6. YENİ RESİM YÜKLEME (File: yeni_resimler[])
        if (isset($_FILES['yeni_resimler']['name'][0]) && !empty($_FILES['yeni_resimler']['name'][0])) {
            $mevcut_sayi = $db->query("SELECT COUNT(*) FROM ilan_resimleri WHERE ilan_id = $id")->fetchColumn();
            $kalan_hak = 5 - $mevcut_sayi;
            $dizin = "../../yuklemeler/ilanlar/";

            foreach ($_FILES['yeni_resimler']['name'] as $key => $name) {
                if ($kalan_hak <= 0) break;
                if ($_FILES['yeni_resimler']['error'][$key] == 0) {
                    $gecici_yol = $_FILES['yeni_resimler']['tmp_name'][$key];
                    $uzanti     = strtolower(pathinfo($name, PATHINFO_EXTENSION));
                    $izinler    = ['jpg', 'jpeg', 'png', 'webp'];

                    if (in_array($uzanti, $izinler)) {
                        $yeni_ad = "zbox_" . uniqid() . "." . $uzanti;
                        if (move_uploaded_file($gecici_yol, $dizin . $yeni_ad)) {
                            $db->prepare("INSERT INTO ilan_resimleri (ilan_id, dosya_adi, ana_resim) VALUES (?, ?, 0)")->execute([$id, $yeni_ad]);
                            $kalan_hak--;
                        }
                    }
                }
            }
        }

        // BAŞARILI
        header("Location: ../ilanlarim.php?islem=guncellendi");
        exit;

    } else {
        // HATA DURUMUNDA
        header("Location: ../ilanlarim.php?hata=sistem");
        exit;
    }
}
?>