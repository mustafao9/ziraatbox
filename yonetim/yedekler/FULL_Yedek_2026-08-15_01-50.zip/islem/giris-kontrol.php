<?php
/**
 * ZiraatBox - Giriş Kontrol Motoru v7.0
 * Mustafa Satılmış - İncirliova / Aydın
 */
ob_start();
require_once __DIR__ . "/../sistem/ayar.php";

if (isset($_POST['giris_yap'])) {
    
    $giris_bilgisi = trim($_POST['giris_bilgisi']);
    $giris_sifre   = $_POST['giris_sifre'];
    $captcha       = $_POST['g-recaptcha-response'];

    // 1. reCAPTCHA Doğrulama (ayar.php'deki RECAPTCHA_SECRET_KEY ile)
    if (empty($captcha)) {
        $_SESSION['hata'] = "Lütfen robot olmadığınızı doğrulayın.";
        header("Location: " . URL . "/giris.php"); exit;
    }

    $verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".RECAPTCHA_SECRET_KEY."&response=".$captcha);
    $response = json_decode($verify);

    if (!$response->success) {
        $_SESSION['hata'] = "Güvenlik doğrulaması başarısız.";
        header("Location: " . URL . "/giris.php"); exit;
    }

    try {
        // 2. VERİTABANI SORGUSU (SQL Dökümündeki 'email' ve 'telefon' sütunları)
        $sorgu = $db->prepare("SELECT * FROM uyeler WHERE (email = ? OR telefon = ?) LIMIT 1");
        $sorgu->execute([$giris_bilgisi, $giris_bilgisi]);
        $uye = $sorgu->fetch();

        // 3. ŞİFRE DOĞRULAMA
        if ($uye && password_verify($giris_sifre, $uye['sifre'])) {
            
            $_SESSION['uye_id']   = $uye['id'];
            $_SESSION['ad_soyad'] = $uye['ad_soyad'];
            $_SESSION['yetki']    = $uye['yetki'];

            // 🚀 KESİN YÖNLENDİRME
            header("Location: " . URL . "/index.php"); 
            exit;

        } else {
            $_SESSION['hata'] = "Giriş bilgileri veya şifre hatalı.";
            header("Location: " . URL . "/giris.php"); exit;
        }

    } catch (PDOException $e) {
        $_SESSION['hata'] = "Teknik Hata: " . $e->getMessage();
        header("Location: " . URL . "/giris.php"); exit;
    }

} else {
    header("Location: " . URL . "/index.php"); exit;
}
ob_end_flush();